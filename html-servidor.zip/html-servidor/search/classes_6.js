var searchData=
[
  ['list_204',['List',['../classList.html',1,'']]],
  ['logicerror_205',['LogicError',['../classJson_1_1LogicError.html',1,'Json']]]
];
