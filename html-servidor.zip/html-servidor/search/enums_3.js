var searchData=
[
  ['precisiontype_376',['PrecisionType',['../namespaceJson.html#af6e1447a3c43e3a62e11050dd0a11ce8',1,'Json']]]
];
