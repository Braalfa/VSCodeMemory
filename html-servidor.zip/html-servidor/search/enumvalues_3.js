var searchData=
[
  ['decimalplaces_384',['decimalPlaces',['../namespaceJson.html#af6e1447a3c43e3a62e11050dd0a11ce8aaee1bf0411c550a0bb2996b7b67cae87',1,'Json']]]
];
