var searchData=
[
  ['exception_197',['Exception',['../classJson_1_1Exception.html',1,'Json']]]
];
