var searchData=
[
  ['list_97',['List',['../classList.html',1,'']]],
  ['logicerror_98',['LogicError',['../classJson_1_1LogicError.html',1,'Json']]]
];
