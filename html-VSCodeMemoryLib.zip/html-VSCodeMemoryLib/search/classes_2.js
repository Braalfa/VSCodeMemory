var searchData=
[
  ['exception_219',['Exception',['../classJson_1_1Exception.html',1,'Json']]]
];
