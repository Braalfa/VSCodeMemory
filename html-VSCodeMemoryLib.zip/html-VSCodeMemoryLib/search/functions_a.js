var searchData=
[
  ['login_330',['logIn',['../classClient.html#a3aa355ae8e6adbdc6872b6d0dab48aa1',1,'Client']]]
];
