var searchData=
[
  ['jsoncpp_5fdeprecated_328',['JSONCPP_DEPRECATED',['../namespaceJson.html#a49095baf50a6d13e2dfacd20aea5ad3e',1,'Json::JSONCPP_DEPRECATED(&quot;Use CharReader and CharReaderBuilder instead.&quot;) JSON_API Reader'],['../namespaceJson.html#a677dd20047c0c6e4eb16c5f1b53f703c',1,'Json::JSONCPP_DEPRECATED(&quot;Use StreamWriter instead&quot;) JSON_API Writer'],['../namespaceJson.html#a9013c5f4f4ff260225b101a18af45262',1,'Json::JSONCPP_DEPRECATED(&quot;Use StreamWriterBuilder instead&quot;) JSON_API StyledStreamWriter']]]
];
