var searchData=
[
  ['list_227',['List',['../classList.html',1,'']]],
  ['logicerror_228',['LogicError',['../classJson_1_1LogicError.html',1,'Json']]]
];
